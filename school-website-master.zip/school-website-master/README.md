# school-website
HTML boilerplate template for school website


[Demo](http://sms.hrshadhin.me)

# usage
    npm install
    npm run dev
    #or
    npm run build

# screenshots

![](src/screenshots/1.png)
